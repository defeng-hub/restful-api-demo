<template>
  <div class="page">
    <div class="title">我的课程</div>
    <div class="line"></div>

    <div class="products">
      <div class="obj">
        <div class="iimg">
          <img src="@/assets/byth/index/i_img1@2x.png" >
        </div>
        <div class="name">
          <div class="name1">笔试双科理论网课（2023版）</div>
          <div class="name2">有效期：2023.08.01 - 2024.08.01</div>
        </div>

        <div class="info green">观看至：第三讲  结构化面试概论</div>

        <div class="goto">开始学习</div>
      </div>

      <!-- <div class="nodata" v-if="false">
        <div>
          <img src="@/assets/byth/index/pic_class@2x.png"  style="width: 3.88rem;height: 3.16rem;">
          <div class="nodata-text">暂无购买课程</div>
        </div>
      </div> -->


 
    </div>

  </div>

</template>

<script>
export default {
  name: 'bythIndex',
  components: {
  },
  data() {
    return {
    }
  },
  created(){

  },
  methods: {

  }
}
</script>

<style lang="scss" scoped>
.page{
  padding: 0.3rem 2.6rem;

}
.title{
  height: 0.37rem;
  font-size: 0.26rem;
  font-weight: 600;
  color: #333333;
  line-height: 0.37rem;
}
.line{
  margin-top: 20px;
  width: 14rem;
  height: 1px;
  border: 1px solid #D5D5D5;
}

.products{
  margin-top: 0.2rem;
}

.obj{
  margin-top: 0.16rem;
  width: 14rem;
  background: #FFFFFF;
  box-shadow: 1px 1px 4px 0 #DFECF5;
  border-radius: 0.08rem;
  padding: 0.22rem 0.45rem 0.26rem 0.25rem;
  display: flex;
  justify-content: space-between;

  .iimg{
    img{
      width: 1.88rem;
      height: 1.88rem;
    }
    
  }
  .info{
    margin-right: 2.8rem;
    height: 0.28rem;
    font-size: 0.18rem;
    font-family: PingFangSC-Medium, PingFang SC;
    font-weight: 500;
    margin-top: 0.81rem;
  }
  .green{
    color: #02BD84;

  }
  .name{
    flex: 1;
    margin-top: 0.46rem;
    margin-left: 0.38rem;
    .name1{
      font-size: 0.23rem;
      font-family: PingFangSC-Semibold, PingFang SC;
      font-weight: 600;
      color: #333333;
      line-height: 0.32rem;
    }
    .name2{
      margin-top: 0.08rem;
      height: 0.28rem;
      font-size: 0.18rem;
      font-weight: 400;
      color: #999999;
      line-height: 0.28rem;
    }
  }

  .goto{
    width: 1.2rem;
    height: 0.4rem;
    background: #02BD84;
    border-radius: 0.04rem;
    
    text-align: center;
    font-size: 0.14rem;
    font-weight: 600;
    color: #FFFFFF;
    line-height: 0.4rem;
    margin-top: 0.74rem;
  }
}
.nodata{
  display: flex;
  justify-content: center;
  align-items: center;
  .nodata-text{
    margin-top: 8px;
    text-align: center;
    height: 0.33rem;
    font-size: 0.24rem;
    font-weight: 400;
    color: #999999;
    line-height: 0.33rem;
  }

}
</style>
