import service from '@/utils/request'

//获取全部订单
export const GetOrder = () => {
  return service({
    url: '/order/GetOrder',
    method: 'post',
    data
  })
}