import service from '@/utils/request'

// @Summary 更改角色api权限
export const UpdateCasbin = (data) => {
  return service({
    url: '/CasbinService/UpdateCasbin',
    method: 'post',
    data
  })
}

// @Summary 获取权限列表
export const getPolicyPathByAuthorityId = (data) => {
  return service({
    url: '/CasbinService/GetPolicyPathByAuthorityId',
    method: 'post',
    data
  })
}
