import service from '@/utils/request'

// @Summary 用户登录
export const login = (data) => {
  return service({
    url: '/UserService/Login',
    method: 'post',
    data: data
  })
}
// @Summary jwt加入黑名单, 退出登录
// @Success 200 {string} string "{"success":true,"data":{},"msg":"拉黑成功"}"
export const logout = () => {
  return service({
    url: '/UserService/Logout',
    method: 'post'
  })
}

// TODO:aa
// @Summary 获取验证码
export const captcha = (data) => {
  return service({
    url: '/base/captcha',
    method: 'post',
    data: data
  })
}

// @Summary 用户注册
export const register = (data) => {
  return service({
    url: '/UserService/Register',
    method: 'post',
    data: data
  })
}

// @Summary 修改密码
export const changePassword = (data) => {
  return service({
    url: '/UserService/ChangePassword',
    method: 'post',
    data: data
  })
}

// @Summary 分页获取用户列表
export const getUserList = (data) => {
  return service({
    url: '/UserService/GetUserList',
    method: 'post',
    data: data
  })
}

// @Summary 设置用户权限
export const setUserAuthority = (data) => {
  return service({
    url: '/UserService/SetUserAuthority',
    method: 'post',
    data: data
  })
}

// @Summary 删除用户
export const deleteUser = (data) => {
  return service({
    url: '/UserService/DeleteUser',
    method: 'delete',
    data: data
  })
}

// @Summary 设置用户信息
export const setUserInfo = (data) => {
  return service({
    url: '/UserService/SetUserInfo',
    method: 'put',
    data: data
  })
}

// @Summary 设置用户信息
export const setSelfInfo = (data) => {
  return service({
    url: '/UserService/SetSelfInfo',
    method: 'put',
    data: data
  })
}

// @Summary 设置用户权限
export const setUserAuthorities = (data) => {
  return service({
    url: '/UserService/SetUserAuthorities',
    method: 'post',
    data: data
  })
}

// @Summary 获取用户信息
export const getUserInfo = () => {
  return service({
    url: '/UserService/GetUserInfo',
    method: 'get'
  })
}

export const resetPassword = (data) => {
  return service({
    url: '/UserService/ResetPassword',
    method: 'post',
    data: data
  })
}