import service from '@/utils/request'

// @Summary 用户登录 获取动态路由
export const asyncMenu = () => {
  return service({
    url: '/MenuService/getMenu',
    method: 'post'
  })
}

// @Summary 获取menu列表
export const getMenuList = (data) => {
  return service({
    url: '/MenuService/getMenuList',
    method: 'post',
    data
  })
}

// @Summary 新增基础menu
export const addBaseMenu = (data) => {
  return service({
    url: '/MenuService/addBaseMenu',
    method: 'post',
    data
  })
}

// @Summary 获取基础路由列表
export const getBaseMenuTree = () => {
  return service({
    url: '/MenuService/getBaseMenuTree',
    method: 'post'
  })
}

// @Summary 添加用户menu关联关系
export const addMenuAuthority = (data) => {
  return service({
    url: '/MenuService/addMenuAuthority',
    method: 'post',
    data
  })
}

// @Summary 获取用户menu关联关系
export const getMenuAuthority = (data) => {
  return service({
    url: '/MenuService/getMenuAuthority',
    method: 'post',
    data
  })
}

// @Summary 获取用户menu关联关系
export const deleteBaseMenu = (data) => {
  return service({
    url: '/MenuService/deleteBaseMenu',
    method: 'post',
    data
  })
}

// @Summary 修改menu列表
export const updateBaseMenu = (data) => {
  return service({
    url: '/MenuService/updateBaseMenu',
    method: 'post',
    data
  })
}

// @Summary 根据id获取菜单
export const getBaseMenuById = (data) => {
  return service({
    url: '/MenuService/getBaseMenuById',
    method: 'post',
    data
  })
}
