<template>
  <div class="main">
    <div class="box1_LoginResgister">
      <div class="box2_title">登录/注册</div>
      <el-form ref="loginForm" :model="loginForm" :rules="rules" label-position="left" @keyup.enter="submit">
        <el-form-item label-width="0.5rem" prop="phone">
          <el-input style="width: 4.47rem" v-model="loginForm.phone" placeholder="请输入手机号"></el-input>
        </el-form-item>
        <el-form-item label-width="0.5rem" prop="yzm_num">
          <el-input style="width: 2.9rem" v-model="loginForm.yzm_num" placeholder="请输入验证码"></el-input>
          <el-button class="sendButton" type="success" @click="send(loginForm.phone)" :disabled="isDisposed"
            v-if="!isSending">获取验证码</el-button>
          <el-button class="sendButton2" type="success" :disabled="true" v-else="isSending">{{ waitTime }}s秒后重新发送</el-button>
        </el-form-item>
        <el-form-item label-width="0.5rem">
          <el-button class="loginButton" type="success" @click="submit()">登录/注册</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>
<script>
import { mapActions } from 'vuex'
export default {
  name: 'Login',
  data() {
    const checkPhone = (rules, value, callback) => {
      if (value.length != 11) {
        return callback(new Error('号码长度有误，请检查后重新输入！'))
      }
      let tel = /^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\d{8}$/;
      if (!tel.test(value)) {
        return callback(new Error('请输入正确的手机号码！'))
      } else {
        callback();
      }
    }

    return {
      isSending: false,
      loginForm: {
        phone: '',
        yzm_num: '',//输入的验证码         
      },
      isDisposed: false,//按钮是否可点
      codeBtnWorld: "获取验证码",
      waitTime: 61,
      rules: {
        phone: [
          // {required:true,message:"请输入手机号",trigger:"blur"},
          {required:true, validator: checkPhone,trigger:"blur" }
        ]
      }
    };
  },
  methods: {
    ...mapActions('user', ['LoginIn']),
    //发送验证码
    async send(phone) {
      // this.$refs.loginForm.validate(async(v) =>{
      //   if(v){
      //     console.info("v+++++:"+v)
      //     const res = await SendPhoneMessage({ 'phone': phone })
      //     if(res.code == 0){
      //       console.info("验证码发送成功")
      //       this.phoneTimer()  // 设置定时器，60s
      //       this.isSending = true;
      //     }
      //   }
      // })
    },
    async login(){
      return await this.LoginIn(this.loginForm)
    },
    async submit() {
      try{
        this.$refs.loginForm.validate(async(v) =>{
        if(v){
          console.info("登录成功")
          const flag = await this.login()
          console.info("flag:"+flag)
        }
      })
      }catch(error){
        console.info(error)
      }

    },
    phoneTimer() {
      const that = this
      that.waitTime--
      const timer = setInterval(function () {
        if (that.waitTime >= 1) {
          that.waitTime--
        } else {
          that.waitTime = 61
          that.isSending = false;
          clearInterval(timer)
        }
      }, 1000)

    }


  }
};
</script>

<style lang="scss">
.main {
  background: (#333333, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;

  .box1_LoginResgister {
    margin-top: 1.5rem;
    width: 5.5rem;
    height: 5.5rem;
    background: #FFFFFF;
    border-radius: .25rem;

    .el-form {
      margin-top: 1.50rem;
      position: absolute;
      width: 100%;
    }

    .el-form-item {
      margin-bottom: .40rem;
    }

    .el-form-item__error {
      padding-top: 0.08rem;
      font-size: 0.15rem;
    }

    .box2_title {
      position: absolute;
      height: .45rem;
      font-size: .32rem;
      font-weight: 500;
      line-height: .45rem;
      text-align: center;
      padding: .69rem 1.98rem .59rem 2.08rem;
    }

    .input {
      border-radius: .08rem;

    }

    div.el-input {
      --el-input-focus-border: #999999;
    }

    .el-input__inner {
      &::placeholder {
        color: #999999
      }

      height:.64rem;
      font-size: .2rem;
      border-radius:.08rem;
    }

    .sendButton {
      width: 1.45rem;
      height: .64rem;
      background: #02BD84;
      font-size: .2rem;
      margin-left: .12rem;
      padding-left: -.12rem;
    }

    .sendButton2 {
      width: 1.45rem;
      height: .64rem;
      background: #DDDDDD;
      border-color:  #DDDDDD;
      font-size: .12rem;
      color: #818183;
      margin-left: .12rem;
    }

    .loginButton {
      width: 4.47rem;
      height: .73rem;
      font-size: .24rem;
      background: #02BD84;
      line-height: .33rem;
      margin-bottom: 0.85rem;
      margin-top: 0.2rem;
      color: #FFFFFF;

    }

    .el-button {
      border-radius: .08rem !important;

    }


  }

}
</style>  