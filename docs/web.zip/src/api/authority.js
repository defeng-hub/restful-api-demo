import service from '@/utils/request'

// @Summary 获取角色列表
export const getAuthorityList = (data) => {
  return service({
    url: '/AuthorityService/getAuthorityList',
    method: 'post',
    data
  })
}

// @Summary 删除角色
export const deleteAuthority = (data) => {
  return service({
    url: '/AuthorityService/deleteAuthority',
    method: 'post',
    data
  })
}

// @Summary 创建角色
export const createAuthority = (data) => {
  return service({
    url: '/AuthorityService/createAuthority',
    method: 'post',
    data
  })
}

// @Summary 拷贝角色
export const copyAuthority = (data) => {
  return service({
    url: '/AuthorityService/copyAuthority',
    method: 'post',
    data
  })
}

// @Summary 设置角色资源权限
export const setDataAuthority = (data) => {
  return service({
    url: '/AuthorityService/setDataAuthority',
    method: 'post',
    data
  })
}

// @Summary 修改角色
export const updateAuthority = (data) => {
  return service({
    url: '/AuthorityService/updateAuthority',
    method: 'put',
    data
  })
}
