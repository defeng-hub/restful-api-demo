import service from '@/utils/request'

// @Summary 获取配置文件内容
export const getSystemConfig = () => {
  return service({
    url: '/SystemService/Info',
    method: 'post'
  })
}

// @Summary 设置配置文件内容
export const setSystemConfig = (data) => {
  return service({
    url: '/SystemService/SetSystemConfig',
    method: 'post',
    data
  })
}
