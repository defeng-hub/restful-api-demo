<template>
  <div class="system">
    <el-form ref="form" :model="config" label-width="240px">
      <!--  System start  -->
      <el-collapse>
        <el-collapse-item title="日志配置" name="3" v-if="config.Log">
          <el-form-item label="级别">
            <el-input v-model.number="config.Log.Level" />
          </el-form-item>
          <el-form-item label="日志格式(text,json)">
            <el-input v-model="config.Log.Format" />
          </el-form-item>
          <el-form-item label="日志文件夹">
            <el-input v-model="config.Log.OutDir" />
          </el-form-item>
          <el-form-item label="日志记录到哪(file,studio)">
            <el-input v-model="config.Log.To" />
          </el-form-item>
        </el-collapse-item>

      </el-collapse>
    </el-form>
    <div class="gva-btn-list">
      <el-button type="primary" size="mini" @click="update">立即更新</el-button>
      <!-- <el-button type="primary" size="mini" @click="reload">重启服务（开发中）</el-button> -->
    </div>
  </div>
</template>

<script>
import { getSystemConfig, setSystemConfig } from '@/api/system'
export default {
  name: 'Config',
  data() {
    return {
      config: {}
    }
  },
  async created() {
    await this.initForm()
  },
  methods: {
    async initForm() {
      const res = await getSystemConfig()
      if (res.code === 0) {
        this.config = res.data.config
        console.log(this.config)
      }
    },
    reload() {},
    async update() {
      const res = await setSystemConfig({ config: this.config })
      if (res.code === 0) {
        this.$message({
          type: 'success',
          message: '配置文件设置成功'
        })
        await this.initForm()
      }
    }
  }
}
</script>

<style lang="scss">
.system {
  background: #fff;
  padding:36px;
  border-radius: 2px;
  h2 {
    padding: 10px;
    margin: 10px 0;
    font-size: 16px;
    box-shadow: -4px 0px 0px 0px #e7e8e8;
  }
  ::v-deep(.el-input-number__increase){
    top:5px !important;
  }
  .gva-btn-list{
    margin-top:16px;
  }
}
</style>
